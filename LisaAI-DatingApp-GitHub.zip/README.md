
# Lisa AI Dating App

A private iOS SwiftUI app designed to help you manage your personal dating journal, message starters, and emotional tracking.

## Features

- 💌 Personal profile display
- 💬 Message templates for starting conversations
- 📓 Private in-app journal
- 🧘 Calm, respectful design for emotional support

## How to Build

1. Open this project in Xcode 15+ (macOS Sonoma or newer recommended)
2. Use a free Apple ID to sign the app
3. Select your iPhone as target device
4. Run the app on your iPhone via cable (no App Store needed)

## Notes

- This is a private emotional tool — not for public publishing.
- Does not require Apple Developer Program to test on your own device.

## License

This app is private-use only. Do not redistribute without permission.
